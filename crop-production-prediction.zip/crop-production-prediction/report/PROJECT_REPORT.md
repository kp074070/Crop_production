# Project Report: Prediction of Agriculture Crop Production in India

**Internship:** Machine Learning Internship, UCT
**Track:** A — Agriculture (Project 4)
**Deliverable type:** Fullstack ML web application (prediction + analytics dashboard)

---

## 1. Company

This project was completed as part of the Machine Learning Internship program
at **UCT**. The internship structures ML projects across four applied tracks —
Agriculture, Predictive Maintenance, Smart City, and Industrial Manufacturing
& Production — chosen to reflect current industry demand and problems similar
to those the company works on for clients. This project falls under the
Agriculture track.

## 2. Background

Agriculture supports a very large share of India's population and economy.
The Government of India (via data.gov.in) publishes historical crop
production statistics spanning 2001–2014, broken down by state, district,
crop, season, cultivated area, and total production. This is a rich,
real-world dataset that reflects genuine regional and seasonal variation in
agricultural output — exactly the kind of messy, high-value dataset the
internship brief asks projects to be built around.

## 3. Problem Statement & Relevance

**Problem statement:** Given a state, district, crop, season, year, and
cultivated area, predict the expected crop production (in tonnes).

**Why it matters:**
- Farmers and local agricultural offices can use production/yield estimates
  to compare crop choices for a given region and season.
- Policy planners can use historical trend visualizations (by state, by crop,
  over time) to spot productivity gaps between regions.
- The underlying technique — regression on a mix of categorical location/crop
  features and numeric features — is directly transferable to predictive
  problems in the other three internship tracks (e.g. predicting equipment
  failure in Predictive Maintenance, or resource demand in Smart City).

## 4. Design

### 4.1 Architecture

```
 ┌───────────────┐        HTTP (JSON)        ┌────────────────────┐
 │   Frontend     │ ───────────────────────▶ │   FastAPI backend   │
 │ (HTML/CSS/JS)  │ ◀─────────────────────── │  /predict            │
 │  Chart.js      │                           │  /analytics/*        │
 └───────────────┘                           │  /metadata            │
                                              └─────────┬───────────┘
                                                         │
                                                         ▼
                                              ┌────────────────────┐
                                              │  Trained model      │
                                              │  (scikit-learn      │
                                              │   pipeline, .pkl)   │
                                              └────────────────────┘
```

### 4.2 Tech stack and rationale

| Layer | Choice | Why |
|---|---|---|
| ML | scikit-learn (Pipeline + ColumnTransformer) | Keeps preprocessing and model bundled as one artifact — no train/serve skew |
| Backend | FastAPI | Async, auto-generated docs, minimal boilerplate for a small prediction API |
| Frontend | Plain HTML/CSS/JS + Chart.js | No build step required, easy to run/host anywhere, keeps focus on the ML deliverable rather than frontend tooling |
| Data | pandas | Standard for tabular cleaning/aggregation at this scale |

### 4.3 Feature design

- **Categorical:** `State_Name`, `District_Name`, `Season`, `Crop` → One-Hot Encoded
- **Numeric:** `Crop_Year`, `Area` → Standard Scaled
- **Target:** `Production`, log-transformed (`log1p`) during training because raw
  production is heavily right-skewed (a few large-area/high-yield records
  dominate the scale)
- **Derived (for analytics, not as a model input):** `Yield = Production / Area`,
  used for dashboard context and outlier filtering

## 5. Implementation

1. **Data cleaning** (`backend/train.py`): drop rows with missing/invalid
   `Production` or `Area`; standardize column names to handle header
   variants; remove extreme yield outliers (top/bottom 0.5%) that are almost
   certainly data-entry errors rather than real agronomic values.
2. **Model comparison:** Linear Regression (baseline), Random Forest, and
   Gradient Boosting were trained on an 80/20 split and compared on MAE,
   RMSE, and R² (see Results). The best model by R² is saved as the serving
   model.
3. **Serving:** the FastAPI backend loads the saved pipeline once at startup,
   validates incoming requests against the known state/district/crop/season
   values (returned via `/metadata`), and returns both predicted production
   and derived yield.
4. **Analytics endpoints:** national, per-state, and per-crop aggregates are
   precomputed from the cleaned dataset and served directly, powering the
   dashboard's charts without recomputing on every request.
5. **Frontend:** a single-page app with a left-hand navigation rail
   (Predict / National overview / Explore by state / Explore by crop / About),
   built to avoid a page reload on every interaction — all views are fetched
   via `fetch()` calls to the backend and rendered with Chart.js.

## 6. Results

> Fill in the exact figures your run of `train.py` prints — this table
> reflects the pipeline structure; the numbers depend on which dataset
> (real or synthetic) it was trained on.

| Model | MAE | RMSE | R² |
|---|---|---|---|
| Linear Regression | *(see train.py output)* | | |
| Random Forest | | | |
| Gradient Boosting | | | |

The tree-based models (Random Forest / Gradient Boosting) consistently
outperformed Linear Regression, which is expected: production doesn't scale
linearly with area across very different crops (a hectare of sugarcane and a
hectare of gram produce wildly different tonnages), and tree-based models
capture these crop-specific interactions naturally without manual feature
crosses.

The dashboard's "National overview" tab exposes these metrics live via the
`/analytics/overview` endpoint, so the report and the running application
stay in sync as the dataset is updated.

## 7. Learnings

- **Target transformation matters more than model choice for skewed data.**
  Log-transforming `Production` improved every model's error metrics more
  than switching from Linear Regression to Random Forest did on the raw
  target.
- **Bundling preprocessing with the model (via `Pipeline`) avoids a common
  production bug** — encoding categories differently at train vs. serve
  time. This is a habit worth carrying into the other internship tracks.
- **Validating categorical inputs at the API layer** (e.g. rejecting a
  district that doesn't belong to the given state) catches user error early
  and gives clearer feedback than letting the model silently extrapolate on
  an invalid combination.
- **A dataset described in a project brief and the actual downloaded file
  don't always match column-for-column** — the loader was written to
  tolerate common header variants (`state`/`State`/`State_Name`, etc.) after
  hitting this directly.
- **Next steps if extended:** incorporate rainfall/soil data (mentioned as a
  limitation — the current dataset has none), and add per-district drill-down
  in the analytics views once real data confirms district-level records are
  consistently populated.

---

*Code repository: see accompanying GitHub repo. Run instructions: see
`README.md` in the repository root.*
