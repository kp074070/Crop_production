// ---- Config ----
// Change this if your backend runs somewhere other than localhost:8000
const API_BASE = "http://localhost:8000";

const chartColors = {
  green: "#3F6B4F",
  gold: "#C89B3C",
  soil: "#7A5230",
  rust: "#B23A2E",
  deep: "#1B3B2F",
};

let metadata = null;
const chartRegistry = {}; // keep chart instances so we can destroy/redraw on re-select

// ---------------- View switching ----------------
document.querySelectorAll(".rail-link").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".rail-link").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`view-${btn.dataset.view}`).classList.add("active");

    if (btn.dataset.view === "overview" && !chartRegistry.overviewLoaded) loadOverview();
  });
});

// ---------------- Helpers ----------------
async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`GET ${path} failed: ${res.status}`);
  return res.json();
}

async function apiPost(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.detail || `POST ${path} failed`);
  return data;
}

function fmtNumber(n) {
  return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(n);
}

function populateSelect(selectEl, values, { placeholder } = {}) {
  selectEl.innerHTML = "";
  if (placeholder) {
    const opt = document.createElement("option");
    opt.value = "";
    opt.textContent = placeholder;
    opt.disabled = true;
    opt.selected = true;
    selectEl.appendChild(opt);
  }
  values.forEach((v) => {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = v;
    selectEl.appendChild(opt);
  });
}

function destroyChart(key) {
  if (chartRegistry[key]) {
    chartRegistry[key].destroy();
    delete chartRegistry[key];
  }
}

// ---------------- Init: load metadata, populate all dropdowns ----------------
async function init() {
  try {
    metadata = await apiGet("/metadata");
  } catch (err) {
    document.getElementById("form-error").textContent =
      "Could not reach the API. Is the backend running at " + API_BASE + "?";
    return;
  }

  // Predict form
  populateSelect(document.getElementById("f-state"), metadata.states);
  populateSelect(document.getElementById("f-crop"), metadata.crops);
  populateSelect(document.getElementById("f-season"), metadata.seasons);
  updateDistrictOptions("f-state", "f-district");

  document.getElementById("f-state").addEventListener("change", () =>
    updateDistrictOptions("f-state", "f-district")
  );

  // State explorer
  populateSelect(document.getElementById("state-select"), metadata.states);
  document.getElementById("state-select").addEventListener("change", (e) => loadStateView(e.target.value));
  loadStateView(metadata.states[0]);

  // Crop explorer
  populateSelect(document.getElementById("crop-select"), metadata.crops);
  document.getElementById("crop-select").addEventListener("change", (e) => loadCropView(e.target.value));
  loadCropView(metadata.crops[0]);
}

function updateDistrictOptions(stateSelectId, districtSelectId) {
  const state = document.getElementById(stateSelectId).value;
  const districts = metadata.state_district_map[state] || [];
  populateSelect(document.getElementById(districtSelectId), districts);
}

// ---------------- Predict form ----------------
document.getElementById("predict-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById("form-error");
  errorEl.textContent = "";

  const payload = {
    state: document.getElementById("f-state").value,
    district: document.getElementById("f-district").value,
    crop: document.getElementById("f-crop").value,
    season: document.getElementById("f-season").value,
    year: parseInt(document.getElementById("f-year").value, 10),
    area: parseFloat(document.getElementById("f-area").value),
  };

  try {
    const result = await apiPost("/predict", payload);
    document.getElementById("result-empty").classList.add("hidden");
    document.getElementById("result-filled").classList.remove("hidden");
    document.getElementById("result-production").textContent = fmtNumber(result.predicted_production_tonnes);
    document.getElementById("result-yield").textContent =
      fmtNumber(result.predicted_yield_tonnes_per_hectare) + " t/ha";
    document.getElementById("result-model").textContent = result.model_used;
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

// ---------------- Overview ----------------
async function loadOverview() {
  chartRegistry.overviewLoaded = true;
  const data = await apiGet("/analytics/overview");

  const statsEl = document.getElementById("overview-stats");
  statsEl.innerHTML = "";
  addStatBox(statsEl, "Records", fmtNumber(data.total_records));
  addStatBox(statsEl, "Years covered", `${data.year_range[0]}–${data.year_range[1]}`);
  addStatBox(statsEl, "Total production", `${fmtNumber(data.total_production)} t`);
  addStatBox(statsEl, "Best model", data.best_model);

  destroyChart("overviewYear");
  chartRegistry.overviewYear = new Chart(document.getElementById("chart-overview-year"), {
    type: "line",
    data: {
      labels: data.production_by_year.map((r) => r.Crop_Year),
      datasets: [{
        label: "Production (t)",
        data: data.production_by_year.map((r) => r.Production),
        borderColor: chartColors.green,
        backgroundColor: "rgba(63,107,79,0.12)",
        fill: true,
        tension: 0.25,
      }],
    },
    options: baseChartOptions(),
  });

  const topStates = data.production_by_state.slice(0, 10);
  destroyChart("overviewState");
  chartRegistry.overviewState = new Chart(document.getElementById("chart-overview-state"), {
    type: "bar",
    data: {
      labels: topStates.map((r) => r.State_Name),
      datasets: [{ label: "Production (t)", data: topStates.map((r) => r.Production), backgroundColor: chartColors.gold }],
    },
    options: { ...baseChartOptions(), indexAxis: "y" },
  });

  destroyChart("overviewCrop");
  chartRegistry.overviewCrop = new Chart(document.getElementById("chart-overview-crop"), {
    type: "bar",
    data: {
      labels: data.production_by_crop.map((r) => r.Crop),
      datasets: [{ label: "Production (t)", data: data.production_by_crop.map((r) => r.Production), backgroundColor: chartColors.soil }],
    },
    options: baseChartOptions(),
  });

  // Metrics table
  const table = document.getElementById("metrics-table");
  const rows = Object.entries(data.model_metrics);
  table.innerHTML = `
    <tr><th>Model</th><th>MAE</th><th>RMSE</th><th>R²</th></tr>
    ${rows.map(([name, m]) => `
      <tr class="${name === data.best_model ? "best" : ""}">
        <td>${name}${name === data.best_model ? " (selected)" : ""}</td>
        <td class="mono">${m.MAE}</td>
        <td class="mono">${m.RMSE}</td>
        <td class="mono">${m.R2}</td>
      </tr>`).join("")}
  `;
}

// ---------------- State view ----------------
async function loadStateView(state) {
  if (!state) return;
  document.getElementById("state-select").value = state;
  const data = await apiGet(`/analytics/state/${encodeURIComponent(state)}`);

  const statsEl = document.getElementById("state-stats");
  statsEl.innerHTML = "";
  addStatBox(statsEl, "Total production", `${fmtNumber(data.total_production)} t`);
  addStatBox(statsEl, "Total area", `${fmtNumber(data.total_area)} ha`);
  addStatBox(statsEl, "Average yield", `${fmtNumber(data.avg_yield)} t/ha`);

  destroyChart("stateYear");
  chartRegistry.stateYear = new Chart(document.getElementById("chart-state-year"), {
    type: "line",
    data: {
      labels: data.production_by_year.map((r) => r.Crop_Year),
      datasets: [{
        label: "Production (t)",
        data: data.production_by_year.map((r) => r.Production),
        borderColor: chartColors.deep,
        backgroundColor: "rgba(27,59,47,0.12)",
        fill: true,
        tension: 0.25,
      }],
    },
    options: baseChartOptions(),
  });

  destroyChart("stateCrop");
  chartRegistry.stateCrop = new Chart(document.getElementById("chart-state-crop"), {
    type: "bar",
    data: {
      labels: data.production_by_crop.map((r) => r.Crop),
      datasets: [{ label: "Production (t)", data: data.production_by_crop.map((r) => r.Production), backgroundColor: chartColors.gold }],
    },
    options: baseChartOptions(),
  });
}

// ---------------- Crop view ----------------
async function loadCropView(crop) {
  if (!crop) return;
  document.getElementById("crop-select").value = crop;
  const data = await apiGet(`/analytics/crop/${encodeURIComponent(crop)}`);

  const statsEl = document.getElementById("crop-stats");
  statsEl.innerHTML = "";
  addStatBox(statsEl, "Total production", `${fmtNumber(data.total_production)} t`);
  addStatBox(statsEl, "Top state", data.top_states[0] ? data.top_states[0].State_Name : "—");

  destroyChart("cropYear");
  chartRegistry.cropYear = new Chart(document.getElementById("chart-crop-year"), {
    type: "line",
    data: {
      labels: data.production_by_year.map((r) => r.Crop_Year),
      datasets: [{
        label: "Production (t)",
        data: data.production_by_year.map((r) => r.Production),
        borderColor: chartColors.rust,
        backgroundColor: "rgba(178,58,46,0.10)",
        fill: true,
        tension: 0.25,
      }],
    },
    options: baseChartOptions(),
  });

  destroyChart("cropState");
  chartRegistry.cropState = new Chart(document.getElementById("chart-crop-state"), {
    type: "bar",
    data: {
      labels: data.top_states.map((r) => r.State_Name),
      datasets: [{ label: "Production (t)", data: data.top_states.map((r) => r.Production), backgroundColor: chartColors.green }],
    },
    options: { ...baseChartOptions(), indexAxis: "y" },
  });
}

// ---------------- Shared chart helpers ----------------
function baseChartOptions() {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { display: false } },
      y: { grid: { color: "#EEE9DC" } },
    },
  };
}

function addStatBox(container, label, value) {
  const box = document.createElement("div");
  box.className = "stat-box";
  box.innerHTML = `<div class="label">${label}</div><div class="value">${value}</div>`;
  container.appendChild(box);
}

init();
