"""
train.py
--------
Trains crop production prediction models.

Data loading order:
  1. If ../data/crop_production.csv exists with real columns -> uses it.
  2. Otherwise falls back to the synthetic sample (run generate_sample_data.py first).

Outputs (into backend/model/):
  model.pkl        -> best trained model (pipeline: preprocessing + regressor)
  metadata.pkl      -> dropdown values (states, districts, crops, seasons) + metrics
"""

import os
import json
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

try:
    from sklearn.ensemble import GradientBoostingRegressor
    HAS_GB = True
except ImportError:
    HAS_GB = False

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "crop_production.csv")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
os.makedirs(MODEL_DIR, exist_ok=True)


def load_data():
    df = pd.read_csv(DATA_PATH)

    # normalize expected column names (handles slightly different real-dataset headers)
    rename_map = {
        "state": "State_Name", "State": "State_Name",
        "district": "District_Name", "District": "District_Name",
        "crop_year": "Crop_Year", "Year": "Crop_Year",
        "season": "Season",
        "crop": "Crop",
        "area": "Area",
        "production": "Production",
    }
    df = df.rename(columns={c: rename_map.get(c, c) for c in df.columns})

    required = ["State_Name", "District_Name", "Crop_Year", "Season", "Crop", "Area", "Production"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")

    # basic cleaning
    df["Season"] = df["Season"].astype(str).str.strip()
    df["Crop"] = df["Crop"].astype(str).str.strip()
    df["State_Name"] = df["State_Name"].astype(str).str.strip()
    df["District_Name"] = df["District_Name"].astype(str).str.strip()

    df = df.dropna(subset=["Production", "Area"])
    df = df[(df["Area"] > 0) & (df["Production"] >= 0)]

    # derived feature: yield (helps the model a lot, and is useful for the dashboard)
    df["Yield"] = df["Production"] / df["Area"]

    # remove extreme outliers (top/bottom 0.5% of yield) - common real-dataset issue
    lo, hi = df["Yield"].quantile([0.005, 0.995])
    df = df[(df["Yield"] >= lo) & (df["Yield"] <= hi)]

    return df.reset_index(drop=True)


def build_pipeline(model):
    categorical = ["State_Name", "District_Name", "Season", "Crop"]
    numeric = ["Crop_Year", "Area"]

    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
            ("num", StandardScaler(), numeric),
        ]
    )
    return Pipeline(steps=[("preprocess", preprocessor), ("model", model)])


def evaluate(y_true, y_pred):
    return {
        "MAE": round(float(mean_absolute_error(y_true, y_pred)), 3),
        "RMSE": round(float(np.sqrt(mean_squared_error(y_true, y_pred))), 3),
        "R2": round(float(r2_score(y_true, y_pred)), 4),
    }


def main():
    df = load_data()
    print(f"Loaded {len(df)} clean rows")

    features = ["State_Name", "District_Name", "Crop_Year", "Season", "Crop", "Area"]
    target = "Production"

    X = df[features]
    y = np.log1p(df[target])  # log-transform: production is heavily right-skewed

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    candidates = {
        "LinearRegression": LinearRegression(),
        "RandomForest": RandomForestRegressor(n_estimators=200, max_depth=None, random_state=42, n_jobs=-1),
    }
    if HAS_GB:
        candidates["GradientBoosting"] = GradientBoostingRegressor(random_state=42)

    results = {}
    fitted = {}

    for name, model in candidates.items():
        pipe = build_pipeline(model)
        pipe.fit(X_train, y_train)
        preds_log = pipe.predict(X_test)

        # evaluate back in original scale
        preds = np.expm1(preds_log)
        y_test_orig = np.expm1(y_test)

        metrics = evaluate(y_test_orig, preds)
        results[name] = metrics
        fitted[name] = pipe
        print(f"{name}: {metrics}")

    best_name = max(results, key=lambda n: results[n]["R2"])
    best_pipe = fitted[best_name]
    print(f"\nBest model: {best_name} -> {results[best_name]}")

    joblib.dump(best_pipe, os.path.join(MODEL_DIR, "model.pkl"))

    metadata = {
        "best_model": best_name,
        "metrics": results,
        "states": sorted(df["State_Name"].unique().tolist()),
        "state_district_map": (
            df.groupby("State_Name")["District_Name"]
            .unique()
            .apply(lambda arr: sorted(arr.tolist()))
            .to_dict()
        ),
        "crops": sorted(df["Crop"].unique().tolist()),
        "seasons": sorted(df["Season"].unique().tolist()),
        "year_range": [int(df["Crop_Year"].min()), int(df["Crop_Year"].max())],
    }
    with open(os.path.join(MODEL_DIR, "metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)

    # also save cleaned dataset for the analytics endpoints (fast to query, small enough to keep in memory)
    df.to_csv(os.path.join(MODEL_DIR, "clean_data.csv"), index=False)

    print("\nSaved: model.pkl, metadata.json, clean_data.csv")


if __name__ == "__main__":
    main()
