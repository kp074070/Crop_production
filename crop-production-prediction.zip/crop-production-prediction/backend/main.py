"""
main.py - FastAPI backend for Crop Production Prediction

Run:
  pip install -r requirements.txt
  python train.py          # trains model.pkl, metadata.json, clean_data.csv (run once, or after updating data)
  uvicorn main:app --reload --port 8000

API docs auto-available at: http://localhost:8000/docs
"""

import os
import json
import joblib
import pandas as pd
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
MODEL_PATH = os.path.join(MODEL_DIR, "model.pkl")
METADATA_PATH = os.path.join(MODEL_DIR, "metadata.json")
CLEAN_DATA_PATH = os.path.join(MODEL_DIR, "clean_data.csv")

app = FastAPI(
    title="Crop Production Prediction API",
    description="Predicts agricultural crop production (tonnes) based on state, district, crop, season, year and area. "
                 "UCT Machine Learning Internship - Agriculture Track.",
    version="1.0.0",
)

# Allow the frontend (served separately, e.g. on a different port / static host) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---- Load artifacts at startup ----
if not os.path.exists(MODEL_PATH):
    raise RuntimeError(
        "model.pkl not found. Run `python train.py` first (see data/generate_sample_data.py "
        "if you don't have the real dataset yet)."
    )

model = joblib.load(MODEL_PATH)

with open(METADATA_PATH) as f:
    metadata = json.load(f)

clean_df = pd.read_csv(CLEAN_DATA_PATH)


# ---- Schemas ----
class PredictionRequest(BaseModel):
    state: str = Field(..., example="Maharashtra")
    district: str = Field(..., example="Pune")
    crop: str = Field(..., example="Rice")
    season: str = Field(..., example="Kharif")
    year: int = Field(..., ge=2001, le=2035, example=2024)
    area: float = Field(..., gt=0, example=1000.0, description="Area in hectares")


class PredictionResponse(BaseModel):
    predicted_production_tonnes: float
    predicted_yield_tonnes_per_hectare: float
    model_used: str


# ---- Routes ----

@app.get("/")
def root():
    return {"status": "ok", "message": "Crop Production Prediction API is running. See /docs for usage."}


@app.get("/metadata")
def get_metadata():
    """Dropdown values for the frontend form, plus model performance metrics."""
    return metadata


@app.post("/predict", response_model=PredictionResponse)
def predict(req: PredictionRequest):
    if req.state not in metadata["states"]:
        raise HTTPException(status_code=400, detail=f"Unknown state '{req.state}'.")
    valid_districts = metadata["state_district_map"].get(req.state, [])
    if req.district not in valid_districts:
        raise HTTPException(
            status_code=400,
            detail=f"'{req.district}' is not a known district of {req.state}. Valid options: {valid_districts}",
        )
    if req.crop not in metadata["crops"]:
        raise HTTPException(status_code=400, detail=f"Unknown crop '{req.crop}'.")
    if req.season not in metadata["seasons"]:
        raise HTTPException(status_code=400, detail=f"Unknown season '{req.season}'.")

    input_df = pd.DataFrame([{
        "State_Name": req.state,
        "District_Name": req.district,
        "Crop_Year": req.year,
        "Season": req.season,
        "Crop": req.crop,
        "Area": req.area,
    }])

    pred_log = model.predict(input_df)[0]
    production = float(np.expm1(pred_log))
    production = max(0.0, production)
    yield_per_ha = production / req.area

    return PredictionResponse(
        predicted_production_tonnes=round(production, 2),
        predicted_yield_tonnes_per_hectare=round(yield_per_ha, 3),
        model_used=metadata["best_model"],
    )


@app.get("/analytics/state/{state}")
def analytics_by_state(state: str):
    subset = clean_df[clean_df["State_Name"] == state]
    if subset.empty:
        raise HTTPException(status_code=404, detail=f"No data found for state '{state}'.")

    by_year = (
        subset.groupby("Crop_Year")["Production"].sum().reset_index().sort_values("Crop_Year")
    )
    by_crop = (
        subset.groupby("Crop")["Production"].sum().reset_index().sort_values("Production", ascending=False)
    )

    return {
        "state": state,
        "total_production": round(float(subset["Production"].sum()), 2),
        "total_area": round(float(subset["Area"].sum()), 2),
        "avg_yield": round(float(subset["Production"].sum() / subset["Area"].sum()), 3),
        "production_by_year": by_year.to_dict(orient="records"),
        "production_by_crop": by_crop.to_dict(orient="records"),
    }


@app.get("/analytics/crop/{crop}")
def analytics_by_crop(crop: str):
    subset = clean_df[clean_df["Crop"] == crop]
    if subset.empty:
        raise HTTPException(status_code=404, detail=f"No data found for crop '{crop}'.")

    by_year = (
        subset.groupby("Crop_Year")["Production"].sum().reset_index().sort_values("Crop_Year")
    )
    by_state = (
        subset.groupby("State_Name")["Production"].sum().reset_index().sort_values("Production", ascending=False).head(10)
    )

    return {
        "crop": crop,
        "total_production": round(float(subset["Production"].sum()), 2),
        "production_by_year": by_year.to_dict(orient="records"),
        "top_states": by_state.to_dict(orient="records"),
    }


@app.get("/analytics/overview")
def analytics_overview():
    """National-level summary used for the dashboard landing view."""
    by_year = clean_df.groupby("Crop_Year")["Production"].sum().reset_index().sort_values("Crop_Year")
    by_state = (
        clean_df.groupby("State_Name")["Production"].sum().reset_index().sort_values("Production", ascending=False)
    )
    by_crop = (
        clean_df.groupby("Crop")["Production"].sum().reset_index().sort_values("Production", ascending=False)
    )

    return {
        "total_records": int(len(clean_df)),
        "year_range": metadata["year_range"],
        "total_production": round(float(clean_df["Production"].sum()), 2),
        "production_by_year": by_year.to_dict(orient="records"),
        "production_by_state": by_state.to_dict(orient="records"),
        "production_by_crop": by_crop.to_dict(orient="records"),
        "model_metrics": metadata["metrics"],
        "best_model": metadata["best_model"],
    }
