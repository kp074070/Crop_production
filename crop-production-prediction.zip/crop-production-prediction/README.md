# Crop Production Prediction — India

A fullstack machine learning web app that predicts agricultural crop production
in India based on state, district, crop, season, year, and cultivated area.

Built for the **UCT Machine Learning Internship — Agriculture Track (Project 4)**.

---

## What's in this repo

```
crop-production-prediction/
├── data/
│   ├── generate_sample_data.py   # generates a synthetic dataset (schema matches the real one)
│   └── crop_production.csv        # dataset used for training (real or synthetic)
├── backend/
│   ├── train.py                   # cleans data, trains & compares models, saves best one
│   ├── main.py                    # FastAPI app: /predict and /analytics endpoints
│   ├── requirements.txt
│   └── model/                     # generated after running train.py
│       ├── model.pkl
│       ├── metadata.json
│       └── clean_data.csv
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
├── notebooks/
│   └── eda.ipynb                  # exploratory data analysis
└── report/
    └── PROJECT_REPORT.md
```

## 1. Using the REAL dataset (recommended before submitting)

1. Download the dataset from the Google Drive link in the project brief.
2. Save it as `data/crop_production.csv`.
3. Make sure it has these columns (rename them first if the raw file uses different headers):
   `State_Name, District_Name, Crop_Year, Season, Crop, Area, Production`
4. Skip step 2 below (data is already there) — go straight to training.

If you don't have the real file yet, generate a synthetic placeholder so you can build/test everything immediately:

```bash
cd data
python generate_sample_data.py
```

## 2. Train the model

```bash
cd backend
pip install -r requirements.txt
python train.py
```

This prints a comparison of Linear Regression, Random Forest, and Gradient
Boosting on held-out data, and saves the best model plus supporting files into
`backend/model/`.

## 3. Run the backend API

```bash
cd backend
uvicorn main:app --reload --port 8000
```

Visit `http://localhost:8000/docs` for interactive API docs.

## 4. Run the frontend

The frontend is plain HTML/CSS/JS — no build step needed. Just serve the folder:

```bash
cd frontend
python3 -m http.server 5500
```

Then open `http://localhost:5500` in your browser. Make sure the backend
(step 3) is running at the same time — the frontend calls it at
`http://localhost:8000` (change `API_BASE` in `frontend/js/app.js` if you
deploy the backend elsewhere).

## 5. Deployment (optional, for the live demo link)

- **Backend**: Render, Railway, or Fly.io (any host that runs a Python web
  service). Set the start command to
  `uvicorn main:app --host 0.0.0.0 --port $PORT`.
- **Frontend**: Netlify, Vercel, or GitHub Pages (any static host). Update
  `API_BASE` in `app.js` to your deployed backend URL before deploying.

## Features

- **Predict**: form-based prediction of production (tonnes) and yield (t/ha)
  for any state/district/crop/season/year/area combination.
- **National overview**: aggregated production trends, top-producing states,
  crop breakdown, and model performance metrics.
- **Explore by state** / **Explore by crop**: drill-down views with charts.
- **About**: project context matching the internship report requirements.

## Model

- Features: `State_Name, District_Name, Crop_Year, Season, Crop, Area`
- Target: `Production` (log-transformed during training to handle skew)
- Pipeline: One-Hot Encoding (categorical) + Standard Scaling (numeric) →
  Regressor
- Models compared: Linear Regression, Random Forest, Gradient Boosting
- Selection: best R² on a held-out 20% test split

See `report/PROJECT_REPORT.md` for the full write-up (background, problem
statement, design, implementation, results, learnings) as required by the
internship deliverables.
