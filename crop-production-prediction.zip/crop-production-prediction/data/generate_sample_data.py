"""
generate_sample_data.py
------------------------
Generates a SYNTHETIC dataset that mirrors the real-world structure of the
"Crop Production Statistics - India (2001-2014)" dataset from data.gov.in.

Why this exists:
  The real dataset is distributed as a Google Drive link and must be
  downloaded manually. This script lets the rest of the pipeline
  (EDA, training, API, frontend) be built and tested immediately.

To use REAL data instead:
  1. Download the CSV from the Google Drive link in the project brief.
  2. Save it as: data/crop_production.csv
  3. Make sure it has (at minimum) these columns:
       State_Name, District_Name, Crop_Year, Season, Crop, Area, Production
  4. Delete/skip this script — train.py will use the real file automatically.

Run:
  python generate_sample_data.py
"""

import numpy as np
import pandas as pd

np.random.seed(42)

STATES_DISTRICTS = {
    "Uttar Pradesh": ["Lucknow", "Kanpur", "Varanasi", "Meerut", "Agra"],
    "Maharashtra": ["Pune", "Nagpur", "Nashik", "Kolhapur", "Aurangabad"],
    "Punjab": ["Ludhiana", "Amritsar", "Patiala", "Jalandhar"],
    "West Bengal": ["Bardhaman", "Hooghly", "Nadia", "Murshidabad"],
    "Karnataka": ["Belagavi", "Mysuru", "Bengaluru Rural", "Ballari"],
    "Tamil Nadu": ["Coimbatore", "Thanjavur", "Salem", "Madurai"],
    "Andhra Pradesh": ["Guntur", "Krishna", "West Godavari", "Kurnool"],
    "Madhya Pradesh": ["Indore", "Bhopal", "Ujjain", "Hoshangabad"],
    "Bihar": ["Patna", "Gaya", "Muzaffarpur", "Bhagalpur"],
    "Gujarat": ["Ahmedabad", "Rajkot", "Surat", "Vadodara"],
}

# crop -> (season, typical yield in tonnes/hectare mean, std, base cost per hectare)
CROPS = {
    "Rice":       ("Kharif", 2.7, 0.6, 28000),
    "Wheat":      ("Rabi",   3.1, 0.5, 25000),
    "Maize":      ("Kharif", 2.5, 0.5, 20000),
    "Sugarcane":  ("Whole Year", 68.0, 10.0, 90000),
    "Cotton":     ("Kharif", 0.5, 0.15, 35000),
    "Groundnut":  ("Kharif", 1.2, 0.3, 22000),
    "Soyabean":   ("Kharif", 1.1, 0.25, 18000),
    "Bajra":      ("Kharif", 1.3, 0.3, 12000),
    "Jowar":      ("Rabi",   1.0, 0.25, 11000),
    "Gram":       ("Rabi",   1.0, 0.2, 15000),
    "Potato":     ("Rabi",   20.0, 4.0, 45000),
    "Onion":      ("Rabi",   17.0, 3.5, 40000),
}

YEARS = list(range(2001, 2015))

rows = []
for year in YEARS:
    # mild overall productivity trend upward over the years (tech adoption, irrigation)
    year_factor = 1 + (year - 2001) * 0.012
    for state, districts in STATES_DISTRICTS.items():
        for district in districts:
            # each district grows a random subset of crops each year
            n_crops = np.random.randint(4, 8)
            chosen_crops = np.random.choice(list(CROPS.keys()), size=n_crops, replace=False)
            for crop in chosen_crops:
                season, yield_mean, yield_std, cost_per_ha = CROPS[crop]
                area = np.round(np.random.uniform(50, 5000), 2)  # hectares
                yield_per_ha = max(0.05, np.random.normal(yield_mean, yield_std) * year_factor)
                # random regional variation
                yield_per_ha *= np.random.uniform(0.85, 1.15)
                production = np.round(area * yield_per_ha, 2)
                cost = np.round(area * cost_per_ha * np.random.uniform(0.9, 1.1), 2)

                rows.append({
                    "State_Name": state,
                    "District_Name": district,
                    "Crop_Year": year,
                    "Season": season,
                    "Crop": crop,
                    "Area": area,           # hectares
                    "Production": production,  # tonnes
                    "Cost": cost,           # INR, cultivation cost (synthetic, not in original dataset but useful for the app)
                })

df = pd.DataFrame(rows)

# introduce a small amount of realistic missingness, like the real dataset has
mask = np.random.rand(len(df)) < 0.01
df.loc[mask, "Production"] = np.nan

out_path = "crop_production.csv"
df.to_csv(out_path, index=False)
print(f"Generated {len(df)} rows -> {out_path}")
print(df.head())
